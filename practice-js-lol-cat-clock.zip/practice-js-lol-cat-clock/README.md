# Practice JS LOL Cat Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/Karthika-Raj/pen/VwRYmRZ](https://codepen.io/Karthika-Raj/pen/VwRYmRZ).

JavaScript practice creating an interactive clock. Project for a Skillcrush Blueprint.